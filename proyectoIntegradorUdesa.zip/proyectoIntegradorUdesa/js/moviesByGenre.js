window.onload= function(){
	var key = "e59c94a503ea78e9502aa8e308f21eb5"
	var genreSearch = new URLSearchParams(location.search);
	var genre = genreSearch.get('genreId')
	var metodo = "GET"

	var genreUrl = "https://api.themoviedb.org/3/discover/movie?api_key="+ key + "&language=en-US&sort_by=popularity.desc&with_genres=" + genre


	var article = "";
	var section = document.querySelector(".section-genres");
	var p = "";
	var movie = "";
	var title = "";
	var img = "";
	var imgPath = "";
	var link = "";
	var linkPath = "";



	fetch(genreUrl,{
			method: metodo
	})
			.then(function (response) {
					return response.json();
			})
			.then(function (data) {
				console.log(data.results);
				var genre = data.results

				for (var i = 0; i < 6; i++) {
					p = "";
					movie = genre[i];
					title = "";
					img = "";
					imgPath = "https://image.tmdb.org/t/p/original/";

					p = createNode('p');
					title = movie.title;
					p.innerText=title;

					img = createNode('img');
					imgPath += movie.poster_path;
					img.setAttribute("src",imgPath)

					link = createNode('a')
					linkPath = "movieData.html?movieId=" + movie.id
					link.setAttribute("href", linkPath)

					article = createNode('article');
					append(link, p);
					append(link, img);
					append(article, link)
					append(section, article);


				}

			})
			.catch(function (error) {
					console.log("El error es: " + error);
			})
}


function createNode(element) {
  return document.createElement(element); // Create the type of element you pass in the parameters
}

function append(parent, el) {
  return parent.appendChild(el); // Append the second parameter(element) to the first one
}
