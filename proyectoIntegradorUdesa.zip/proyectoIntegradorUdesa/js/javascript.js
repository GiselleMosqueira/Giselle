window.onload = function(){
    estrenos();
		populares();
		ranking();

    prevenirComportamientoPorDefault("form","submit");
    document.querySelector("button.btn-search").addEventListener("click",function(){
        window.location.href = "search.html?searchText="+document.querySelector("form input.input-search").value;
    });
    // esperarAqueExista()
}



var key = "e59c94a503ea78e9502aa8e308f21eb5";

function prevenirComportamientoPorDefault(elementAsString,eventAsString) {
    document.querySelector(elementAsString).addEventListener(eventAsString, function(event){
        event.preventDefault();
    });
}

function estrenos(){
    var section = document.querySelector("section.section-estrenos");

    var metodo = 'POST';
    var estrenosURL = "https://api.themoviedb.org/3/movie/upcoming?api_key="+key;

    var article = "";
    var p = "";
    var movie = "";
		var movieId = "";
    var title = "";
    var img = "";
    var imgPath = "";
		var link = "";
		var linkPath = "";

    fetch(estrenosURL,{
        method: metodo
    })
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            // do stuff with data;
            // console.log(data);
            var movies = data.results;

            for (var i = 0; i < 3; i++) {
                article = "";
                p = "";
                movie = movies[i];
								movieId = movie.id
								title = "";
                img = "";
                imgPath = "https://image.tmdb.org/t/p/original/";
                // console.log(movie);
                p = createNode('p');
                title = movie.title;
                p.innerText=title;

                img = createNode('img');
                imgPath += movie.poster_path;
                img.setAttribute("src",imgPath)
								img.setAttribute("onload", "peliData()")

								link = createNode('a')
								linkPath = "movieData.html?movieId=" + movie.id
								link.setAttribute("href", linkPath)

                article = createNode('article');
								article.setAttribute("id", movieId)
								article.setAttribute("class", "article-movies")

                append(link, p);
                append(link, img);
                append(article, link);
                append(section, article);

            }
        })
        .catch(function (error) {
            // console.log("El error es: " + error);
        })

}

function populares() {
	var section = document.querySelector('section.section-populares')

	var metodo = 'POST';
	var popularesUrl = "https://api.themoviedb.org/3/movie/popular?api_key="+key;


	var article = "";
	var p = "";
	var movie = "";
	var movieId = "";
	var title = "";
	var img = "";
	var imgPath = "";
	var link = "";
	var linkPath = "";

	fetch(popularesUrl,{
			method: metodo
	})
			.then(function (response) {
					return response.json();
			})
			.then(function (data) {
					// do stuff with data;
					// console.log(data);
					var movies = data.results;

					for (var i = 0; i < 3; i++) {
							article = "";
							p = "";
							movie = movies[i];
							movieId = movie.id;
							title = "";
							img = "";
							imgPath = "https://image.tmdb.org/t/p/original/";
							// console.log(movie);
							p = createNode('p');
							title = movie.title;
							p.innerText=title;

							img = createNode('img');
							imgPath += movie.poster_path;
							img.setAttribute("src",imgPath)
							img.setAttribute("onload", "peliData()")

							link = createNode('a')
							linkPath = "movieData.html?movieId=" + movie.id
							link.setAttribute("href", linkPath)

							article = createNode('article');
							article.setAttribute("id", movieId)
							article.setAttribute("class", "article-movies")

							append(link, p);
							append(link, img);
							append(article, link);
							append(section, article);

					}
			})
			.catch(function (error) {
					// console.log("El error es: " + error);
			})
}

function ranking() {
	var section = document.querySelector('section.section-ranking')

	var metodo = 'POST';
	var rankingUrl = "https://api.themoviedb.org/3/movie/top_rated?api_key="+key;


	var article = "";
	var p = "";
	var movie = "";
	var title = "";
	var img = "";
	var imgPath = "";
	var movieId = "";
	var link = "";
	var linkPath = "";

	fetch(rankingUrl,{
			method: metodo
	})
			.then(function (response) {
					return response.json();
			})
			.then(function (data) {
					// do stuff with data;
					// console.log(data);
					var movies = data.results;

					for (var i = 0; i < 3; i++) {
							article = "";
							p = "";
							movie = movies[i];
							movieId=movie.id
							title = "";
							img = "";
							imgPath = "https://image.tmdb.org/t/p/original/";
							// console.log(movie);
							p = createNode('p');
							title = movie.title;
							p.innerText=title;

							img = createNode('img');
							imgPath += movie.poster_path;
							img.setAttribute("src",imgPath)
							img.setAttribute("onload", "peliData()")

							link = createNode('a')
							linkPath = "movieData.html?movieId=" + movie.id
							link.setAttribute("href", linkPath)

							article = createNode('article');
							article.setAttribute("id", movieId)
							article.setAttribute("class", "article-movies")

							append(link, p);
							append(link, img);
							append(article, link);
							append(section, article);
					}
			})
			.catch(function (error) {
					// console.log("El error es: " + error);
			})
}

function peliData() {
var seccionMovies = document.querySelector(".section-movies")

	console.log("Se activo peliData()");

		if (seccionMovies.hasChildNodes()) {
			var movieArray = document.querySelectorAll(".article-movies")
			console.log(movieArray);

			// movie.addEventListener("click", function(){
			// 	window.location = "movieData.html"
			// 	var movieId = this.
			// 	window.localStorage.setItem("movieId", movieId)
			//
			// })
		}


	}







function createNode(element) {
  return document.createElement(element); // Create the type of element you pass in the parameters
}

function append(parent, el) {
  return parent.appendChild(el); // Append the second parameter(element) to the first one
}



function esperarAqueExista(){
  var section = document.querySelector("section.section-estrenos");
  var tieneHijos = section.hasChildNodes()
  do {
    console.log("no existe aun");
  } while (tieneHijos != null || tieneHijos != "");


}
