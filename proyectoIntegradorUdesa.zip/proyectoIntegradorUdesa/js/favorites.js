window.onload = function(){
	if (JSON.parse(localStorage.getItem('favoritos')) != null || JSON.parse(localStorage.getItem('favoritos')) != "[]") {
		var favoritosArray = JSON.parse(localStorage.getItem('favoritos'))
		for (var i = 0; i < favoritosArray.length; i++) {
			console.log(favoritosArray[i]);
			var title = favoritosArray[i].title
			var id = favoritosArray[i].id
			var img = favoritosArray[i].img

			var nodeId = createNode("a")
			nodeId.setAttribute("href", 'movieData.html?movieId='+id)
			var nodeTitle = createNode("h2")
			nodeTitle.innerText = title
			var nodeImg = createNode("img")
			nodeImg.setAttribute("src", img)
			var article = createNode("article")

			var section = document.querySelector(".section-favorites")

			append(nodeId,nodeTitle)
			append(nodeId,nodeImg)
			append(article,nodeId)
			append(section,article)

		}
	}

	function createNode(element) {
	  return document.createElement(element); // Create the type of element you pass in the parameters
	}

	function append(parent, el) {
	  return parent.appendChild(el); // Append the second parameter(element) to the first one
	}

}
