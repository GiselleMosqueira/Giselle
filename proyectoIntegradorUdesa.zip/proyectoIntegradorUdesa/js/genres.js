window.onload = function() {
	var key = "e59c94a503ea78e9502aa8e308f21eb5";
	var metodo = 'GET';

	var article = "";
	var p = "";
	var movie = "";
	var title = "";
	var img = "";
	var imgPath = "";

	var genresUrl = "https://api.themoviedb.org/3/genre/movie/list?api_key=" + key + "&language=en-US"

	fetch(genresUrl,{
			method: metodo
	})
			.then(function (response) {
					return response.json();
			})
			.then(function (data) {

					console.log(data);


			})
			.catch(function (error) {
					console.log("El error es: " + error);
			})
}
