window.onload = function(){
    getDataFromURL();
    prevenirComportamientoPorDefault("form","submit")
    document.querySelector("button.btn-search").addEventListener("click",search);
}

var key = "e59c94a503ea78e9502aa8e308f21eb5";

// var queryString = "?para1=" + value1 + "&para2=" + value2;
// window.location.href = "page2.html" + queryString;
function prevenirComportamientoPorDefault(elementAsString,eventAsString) {
    document.querySelector(elementAsString).addEventListener(eventAsString, function(event){
        event.preventDefault();
    });
}


function getDataFromURL(){
  var url = new URL(window.location.href );
  var c = url.searchParams.get("searchText");
  console.log(c);
  if ((c != "") || (c != null) || (c != undefined)) {
      document.querySelector("form input.input-search").value = c;
      search();
  }
}

function search(){
    var searchText = document.querySelector("form input.input-search").value;
    console.log(searchText);

    var searchURL = "https://api.themoviedb.org/3/search/movie?api_key="+key+"&query="+searchText+"&page=1&include_adult=true";
    console.log(searchURL);

    var metodo = 'GET';

    var section = document.querySelector("section.section-search");
    if (section.hasChildNodes()) {
        section.innerHTML = "";
    }

    var article = "";
    var p = "";
    var movie = "";
    var title = "";
    var img = "";
    var imgPath = "";
		var link = "";
		var linkPath = "";

    fetch(searchURL,{
        method: metodo
    })
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            // do stuff with data;
            console.log(data);
            var movies = data.results;

            for (var i = 0; i < data.results.length; i++) {
                article = "";
                p = "";
                movie = movies[i];
                title = "";
                img = "";
                imgPath = "https://image.tmdb.org/t/p/original/";
                console.log(movie);
                p = createNode('p');
                title = movie.title;
                p.innerText=title;

                img = createNode('img');
                imgPath += movie.poster_path;
                img.setAttribute("src",imgPath)

								link = createNode('a')
								linkPath = "movieData.html?movieId=" + movie.id
								link.setAttribute("href", linkPath)

                article = createNode('article');
								append(link, p);
								append(link, img);
								append(article, link);
                append(section, article);

            }
        })
        .catch(function (error) {
            console.log("El error es: " + error);
        })
}

function createNode(element) {
  return document.createElement(element); // Create the type of element you pass in the parameters
}

function append(parent, el) {
  return parent.appendChild(el); // Append the second parameter(element) to the first one
}
