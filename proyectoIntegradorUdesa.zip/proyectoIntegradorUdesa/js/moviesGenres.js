window.onload = function() {
	var key = "e59c94a503ea78e9502aa8e308f21eb5";
	var metodo = 'GET';



	var genresUrl = "https://api.themoviedb.org/3/genre/movie/list?api_key=" + key

	fetch(genresUrl,{
			method: metodo
	})
			.then(function (response) {
					return response.json();
			})
			.then(function (data) {
				console.log(data.genres);
				for (var i = 0; i < data.genres.length; i++) {
					var title =data.genres[i].name;
					var id = data.genres[i].id;
					document.querySelector(".article-genres").innerHTML += '<h2><a class="genre" href="moviesByGenre.html?genreId='+id+'" value="">'+ title+ '</a></h2>'
				}
					// var myArray = document.querySelectorAll(".genre")
					// for (var i = 0; i < myArray.length; i++) {
					// 	// console.log(myArray[i]);
					// 	var element = myArray[i]
					// 	element.addEventListener('click', function(e){
					// 		e.preventDefault()
					// 		var value = this.getAttribute("value")
					// 		window.localStorage.setItem("id", value)
					//
					//
					// 		window.location='moviesByGenre.html'
					// 	})
					// }
			})
			.catch(function (error) {
					console.log("El error es: " + error);
			})




}
