window.onload = function() {
	var key = "e59c94a503ea78e9502aa8e308f21eb5"
	var movieIdSearch = new URLSearchParams(location.search)
	var movieId = movieIdSearch.get('movieId')
	var metodo = "GET"


	var movieUrl = "https://api.themoviedb.org/3/movie/"+movieId+"?api_key=" + key


	var article = document.querySelector(".article-movie");
	var section = document.querySelector(".section-movie");
	var p = "";
	var title = "";
	var img = "";
	var imgPath = "";



	fetch(movieUrl,{
			method: metodo
	})
			.then(function (response) {
					return response.json();
			})
			.then(function (data) {
				console.log(data);
					p = data.overview;
					title = data.title;
					imgPath = "https://image.tmdb.org/t/p/original/";
					img = imgPath + data.poster_path;

					var resumeNode= createNode("p")
					resumeNode.innerText = p

					var titleNode = createNode("h2")
					titleNode.innerText = title

					var imgNode = createNode("img")
					imgNode.setAttribute("src", img)

					var starIcon = createNode("span")
					starIcon.innerHTML = "&#x2729;"
					starIcon.setAttribute("class", "black icon")
					var starIcon2 = createNode("span")
					starIcon2.innerHTML = "&#x2605;"
					starIcon2.setAttribute("class","display-none gold icon")
					var favorite = createNode("p")
					favorite.innerText = "Agregar a favoritos"
					favorite.setAttribute("class", "display")
					var favorite2 = createNode("p")
					favorite2.innerText = "Quitar de favoritos"
					favorite2.setAttribute("class", "display-none")


					append(article, titleNode)
					append(article, imgNode)
					append(article, favorite)
					append(article, favorite2)
					append(article, starIcon)
					append(article, starIcon2)
					append(article, resumeNode)

					var noFavoriteBtn = document.querySelector('span.black')
					var favoriteBtn = document.querySelector('span.display-none')
					var noFavoriteP = document.querySelector('p.display')
					var favoriteP = document.querySelector('p.display-none')

					if (JSON.parse(localStorage.getItem('favoritos')) != null || JSON.parse(localStorage.getItem('favoritos')) != "[]") {
						var favoritosArray = JSON.parse(localStorage.getItem('favoritos'))

						for (var i = 0; i < favoritosArray.length; i++) {
							if (favoritosArray[i].title == title) {
								favoriteBtn.classList.toggle('display-none')
								noFavoriteBtn.classList.toggle('display-none')
								favoriteP.classList.toggle('display-none')
								noFavoriteP.classList.toggle('display-none')

							}
						} //TERMINA EL FOR
					} //TERMINA EL IF



					//AGREGAR A FAVORITOS
					noFavoriteBtn.addEventListener("click", function () {
							favoriteBtn.classList.toggle('display-none')
							noFavoriteBtn.classList.toggle('display-none')
							favoriteP.classList.toggle('display-none')
							noFavoriteP.classList.toggle('display-none')

							if (localStorage.getItem('favoritos') == null || localStorage.getItem('favoritos') == "[]") {
								var favoritosArray = [];
								var favoriteObject = {
									title: title,
									id: data.id,
									img: img,
								}
								favoritosArray.push(favoriteObject)
								localStorage.setItem('favoritos', JSON.stringify(favoritosArray))

							}else {
								var favoritosArray = JSON.parse(localStorage.getItem('favoritos'))
								var favoriteObject = {
									title: title,
									id: data.id,
									img: img,
								}
								favoritosArray.push(favoriteObject)
								localStorage.setItem('favoritos', JSON.stringify(favoritosArray))
								console.log(localStorage.getItem('favoritos'));
							}
					}) //TERMINA EL IF

					//QUITAR DE FAVORITOS
					favoriteBtn.addEventListener("click", function () {
							favoriteBtn.classList.toggle('display-none')
							noFavoriteBtn.classList.toggle('display-none')
							favoriteP.classList.toggle('display-none')
							noFavoriteP.classList.toggle('display-none')
							var favoritosArray = JSON.parse(localStorage.getItem('favoritos'))
							console.log(favoritosArray);

							for (var i = 0; i < favoritosArray.length; i++){
									if (favoritosArray[i].title == title){
										console.log(favoritosArray[i]);
										favoritosArray.splice(i,1)
										localStorage.setItem('favoritos', JSON.stringify(favoritosArray))
									}
							}

					})



			})
			.catch(function (error) {
					console.log("El error es: " + error);
			})


}


function createNode(element) {
  return document.createElement(element); // Create the type of element you pass in the parameters
}

function append(parent, el) {
  return parent.appendChild(el); // Append the second parameter(element) to the first one
}
